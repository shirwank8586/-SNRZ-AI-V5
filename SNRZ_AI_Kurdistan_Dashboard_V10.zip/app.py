from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from market import candles
from snrz_engine import Candle, multi_timeframe
from openai import AsyncOpenAI
from pathlib import Path
import os, json

app = FastAPI(title="SNRZ AI Dashboard", version="10.0")

OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
TIMEFRAMES = ["1mo", "1w", "1d", "4h", "1h", "30m", "15m", "5m"]

SYSTEM_PROMPT = """
You are the SNRZ AI explanation layer for an educational paper/simulation dashboard.
Use only SNRZ concepts present in the supplied dashboard: S, R, SBR, RBS, V.S, V.R,
I-VS, I-VR, PO2, SRR, RSS, Fresh, False Breakout, Liquidity Sweep, Liquidity Run,
Pump Base, Drop Base, GAP Strategy, market structure and candle confirmation.
Do not invent zones, prices, or signals. Explain why the engine says WAIT when confirmation
is incomplete. Clearly distinguish calculated engine output from uncertainty.
Educational/paper use only: no broker connection, no real-money execution, no guaranteed
returns, and no claims that a candidate signal will be profitable.
"""

class AskRequest(BaseModel):
    question: str = ""
    analysis: dict = {}

@app.get("/health")
async def health():
    return {
        "ok": True,
        "chatgpt": bool(os.getenv("OPENAI_API_KEY")),
        "market_data": bool(os.getenv("TWELVE_DATA_API_KEY")),
        "model": OPENAI_MODEL,
        "mode": "paper/educational"
    }

@app.get("/", response_class=HTMLResponse)
async def home():
    html = Path(__file__).with_name("index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)

@app.get("/multi-analysis")
async def multi_analysis():
    all_data = {}
    errors = {}
    for tf in TIMEFRAMES:
        try:
            raw = await candles(tf, outputsize=250)
            all_data[tf] = [
                Candle(
                    time=x["time"], open=x["open"], high=x["high"],
                    low=x["low"], close=x["close"]
                ) for x in raw
            ]
        except Exception as exc:
            all_data[tf] = []
            errors[tf] = str(exc)[:240]

    result = multi_timeframe(all_data)
    price = None
    for tf in ("5m", "15m", "1h", "1d"):
        if all_data.get(tf):
            price = all_data[tf][-1].close
            break

    result["price"] = price
    result["timeframes"] = result.get("analysis", {})
    result["data_status"] = "live" if price is not None else "unavailable"
    result["errors"] = errors
    return result

@app.get("/market-candles/{timeframe}")
async def market_candles(timeframe: str):
    if timeframe not in TIMEFRAMES:
        raise HTTPException(status_code=400, detail="Unsupported timeframe")
    try:
        return {"timeframe": timeframe, "candles": await candles(timeframe, outputsize=120)}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)[:240])

@app.post("/ask-ai")
async def ask_ai(req: AskRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY is not configured on the backend.")
    question = req.question.strip() or "Explain the current SNRZ dashboard."
    payload = json.dumps(req.analysis, ensure_ascii=False, default=str)[:24000]
    client = AsyncOpenAI(api_key=api_key)
    response = await client.responses.create(
        model=OPENAI_MODEL,
        instructions=SYSTEM_PROMPT,
        input=f"User question:\\n{question}\\n\\nDashboard data:\\n{payload}"
    )
    return {"answer": response.output_text}
