SNRZ AI KURDISTAN DASHBOARD — VERSION 10

Files:
- app.py: FastAPI backend and existing route preservation (/health, /multi-analysis, /ask-ai)
- index.html: responsive Sorani Kurdish dashboard prototype
- market.py: Twelve Data client with async request and timeframe mapping
- requirements.txt: Python dependencies

Required Vercel Environment Variables (add as Secret):
- TWELVE_DATA_API_KEY
- OPENAI_API_KEY
Optional:
- OPENAI_MODEL (default: gpt-5.6-luna)
- SYMBOL (default: XAU/USD)

Important:
1. Keep snrz_engine.py from your current repository in the same project root.
2. Replace app.py and market.py with these versions, and add index.html.
3. Update requirements.txt.
4. Redeploy after changing files or environment variables.
5. /multi-analysis now awaits the async market function and constructs Candle objects correctly.
6. Economic news, calendar, currency conversion are deliberately shown as unavailable until real data providers are connected. They are not fabricated.
7. Educational / paper simulation only. No broker connection or real-money order execution.
