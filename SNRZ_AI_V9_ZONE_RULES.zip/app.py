
from fastapi import FastAPI,HTTPException
from fastapi.responses import HTMLResponse
from market import candles
from snrz_engine import Candle,multi_timeframe
app=FastAPI(title="SNRZ AI V9",version="9.0")
HTML="""<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>SNRZ AI V9</title><style>
body{margin:0;background:#07111f;color:#eaf2ff;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}.wrap{max-width:1100px;margin:auto;padding:18px}h1{margin:0}.muted{color:#91a4bd}.card{background:#0d1b2d;border:1px solid #223955;border-radius:16px;padding:16px;margin:14px 0}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.tf{background:#091524;border:1px solid #20344e;border-radius:12px;padding:14px}.sig{font-weight:900;font-size:18px;margin:8px 0}.buy{color:#70e59c}.sell{color:#ff8191}.wait{color:#cbd5e1}.tag{display:inline-block;border:1px solid #35506d;border-radius:999px;padding:2px 8px;margin:2px;font-size:12px}button{padding:10px 15px;border:0;border-radius:10px;font-weight:700}.price{font-size:32px;font-weight:800}@media(max-width:700px){.grid{grid-template-columns:1fr}}</style></head><body><div class="wrap">
<h1>SNRZ AI V9</h1><div class="muted">Zone-first • SNRZ-only • Paper/Educational</div>
<div class="card"><button onclick="load()">Refresh</button><div class="muted">XAUUSD</div><div id="price" class="price">—</div></div>
<div class="card"><b>Strict Zone Signal</b><div id="grid" class="grid">Loading…</div></div>
<div class="card"><b>Rule</b><div class="muted">No BUY/SELL candidate unless price is touching the relevant Support/Resistance zone and the SNRZ condition, market structure and candle confirmation agree. Otherwise WAIT.</div></div>
</div><script>
async function load(){let g=document.getElementById('grid');try{let r=await fetch('/multi-analysis',{cache:'no-store'});let d=await r.json();if(!r.ok)throw Error(d.detail||'API error');let a=d.analysis||{},t=d.timeframes||Object.keys(a),p=null;
g.innerHTML=t.map(k=>{let x=a[k]||{};if(p==null&&x.price!=null)p=x.price;let s=x.signal||'WAIT',c=s.includes('BUY')?'buy':s.includes('SELL')?'sell':'wait';let rr=Array.isArray(x.reasons)?x.reasons:(x.reasons?Object.values(x.reasons).flat():[]);let tags=rr.map(z=>'<span class="tag">'+z+'</span>').join('');let zs=(x.zones||[]).map(z=>'<div class="muted">'+z.direction+' • '+z.type+' '+Number(z.price).toFixed(2)+' • '+(z.touched_now?'PRICE IN ZONE':'waiting for price')+' • '+z.reasons.join(' / ')+'</div>').join('');return '<div class="tf"><b>'+k.toUpperCase()+'</b><div class="sig '+c+'">'+s.replaceAll('_',' ')+'</div><div>'+ (x.structure||'—')+'</div><div>'+ (tags||'<span class="muted">No active SNRZ confirmation</span>')+'</div>'+zs+'</div>'}).join('');document.getElementById('price').textContent=p==null?'—':Number(p).toFixed(2)}catch(e){g.innerHTML='<span>'+e.message+'</span>'}}load();</script></body></html>"""
@app.get("/",response_class=HTMLResponse)
def root(): return HTML
@app.get("/health")
def health(): return {"ok":True,"engine":"SNRZ AI V9","mode":"paper/educational","method":"SNRZ-only"}
@app.get("/multi-analysis")
async def multi_analysis():
    all_data={};errors={};timeframes=["1mo","1w","1d","4h","1h","30m","15m","5m"]
    for tf in timeframes:
        try: all_data[tf]=[Candle(**x) for x in await candles(tf,250)]
        except Exception as e: errors[tf]=str(e)
    if not all_data: raise HTTPException(502,"No market data. Configure TWELVE_DATA_API_KEY on the backend.")
    r=multi_timeframe(all_data);r.update({"timeframes":timeframes,"errors":errors});return r
