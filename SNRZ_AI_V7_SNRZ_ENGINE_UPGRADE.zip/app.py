from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from market import candles
from snrz_engine import Candle, multi_timeframe

app = FastAPI(title="SNRZ AI V7", version="7.2")

HTML = """<!doctype html>
<html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SNRZ AI V7</title>
<style>
body{margin:0;background:#07111f;color:#eaf2ff;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}
.wrap{max-width:1100px;margin:auto;padding:18px}h1{margin:0}.muted{color:#91a4bd}
.card{background:#0d1b2d;border:1px solid #223955;border-radius:16px;padding:16px;margin:14px 0}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.tf{background:#091524;border:1px solid #20344e;border-radius:12px;padding:12px}
.sig{font-weight:800;margin:8px 0}.buy{color:#70e59c}.sell{color:#ff8191}.wait{color:#cbd5e1}
button{padding:10px 15px;border:0;border-radius:10px;font-weight:700}.price{font-size:32px;font-weight:800}
.tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}.tag{padding:4px 7px;border:1px solid #35516f;border-radius:8px;font-size:12px}
.zone{font-size:12px;margin-top:7px;color:#b8c8da}@media(max-width:700px){.grid{grid-template-columns:repeat(2,1fr)}}
</style></head>
<body><div class="wrap">
<h1>SNRZ AI V7</h1><div class="muted">SNRZ-only • Multi-Timeframe • Paper/Educational</div>
<div class="card"><button onclick="load()">Refresh</button><div class="muted">XAUUSD</div><div id="price" class="price">—</div></div>
<div class="card"><b>Multi-Timeframe SNRZ Analysis</b><div id="grid" class="grid">Loading…</div></div>
<div class="card"><b>SNRZ concepts</b><div class="muted">V.S • V.R • I-VS • I-VR • SBR • RBS • SRR • RSS • PO2 • Liquidity Sweep • Liquidity Run • Market Structure • Confirmation</div>
<div class="muted" style="margin-top:8px">The dashboard reports candidates from OHLC data. It does not place live orders.</div></div>
</div>
<script>
function esc(v){return String(v??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));}
async function load(){let g=document.getElementById('grid');try{
let r=await fetch('/multi-analysis',{cache:'no-store'});let d=await r.json();if(!r.ok)throw Error(d.detail||'API error');
let a=d.analysis||{},t=d.timeframes||Object.keys(a),p=null;
g.innerHTML=t.map(k=>{let x=a[k]||{},s=x.signal||'WAIT';if(p==null&&x.price!=null)p=x.price;
let c=s.includes('BUY')?'buy':s.includes('SELL')?'sell':'wait',reasons=Array.isArray(x.reason)?x.reason:[];
let snrz=x.snrz||{},tags=Object.entries(snrz).filter(([_,v])=>v).map(([key])=>'<span class="tag">'+esc(key)+'</span>').join('');
let zones=(x.zones||[]).slice(0,2).map(z=>{let parts=[z.type+' '+Number(z.price).toFixed(2)];if(z.po2)parts.push('PO2');if(z.transition)parts.push(z.transition);if(z.inversion)parts.push(z.inversion);if(z.fresh)parts.push('Fresh');return esc(parts.join(' • '));}).join('<br>');
return '<div class="tf"><b>'+esc(k.toUpperCase())+'</b><div class="sig '+c+'">'+esc(s.replaceAll('_',' '))+'</div><div class="muted">'+esc(x.structure||'—')+'</div><small>'+(reasons.length?reasons.map(esc).join(' • '):'No active confirmation')+'</small><div class="tags">'+tags+'</div>'+(zones?'<div class="zone">'+zones+'</div>':'')+'</div>';}).join('');
document.getElementById('price').textContent=p==null?'—':Number(p).toFixed(2);
}catch(e){g.innerHTML='<span>'+esc(e.message)+'</span>';}}
load();
</script></body></html>"""

@app.get("/", response_class=HTMLResponse)
def root(): return HTML

@app.get("/health")
def health():
    return {"ok":True,"engine":"SNRZ AI V7","mode":"paper/educational","method":"SNRZ-only","status":"online"}

@app.get("/multi-analysis")
async def multi_analysis():
    all_data, errors = {}, {}
    timeframes=["1mo","1w","1d","4h","1h","30m","15m","5m"]
    for tf in timeframes:
        try:
            raw=await candles(tf,250)
            all_data[tf]=[Candle(**x) for x in raw]
        except Exception as e: errors[tf]=str(e)
    if not all_data:
        raise HTTPException(status_code=502,detail="No market data. Configure TWELVE_DATA_API_KEY on the backend.")
    result=multi_timeframe(all_data)
    result.update({"engine":"SNRZ AI V7","mode":"paper/educational","method":"SNRZ-only","timeframes":timeframes,"errors":errors})
    return result
