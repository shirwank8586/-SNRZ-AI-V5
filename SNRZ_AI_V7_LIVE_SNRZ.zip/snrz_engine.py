from dataclasses import dataclass, asdict

BUY_ZONES = {"V.S","I-VR","RBS","SRR","PO2"}
SELL_ZONES = {"V.R","I-VS","SBR","RSS"}

@dataclass
class Candle:
    time: str
    open: float
    high: float
    low: float
    close: float

def bull(c): return c.close > c.open
def bear(c): return c.close < c.open

def pivots(cs,left=2,right=2):
    hs,ls=[],[]
    for i in range(left,len(cs)-right):
        w=cs[i-left:i+right+1]
        if cs[i].high >= max(x.high for x in w): hs.append((i,cs[i].high))
        if cs[i].low <= min(x.low for x in w): ls.append((i,cs[i].low))
    return hs,ls

def structure(cs,lookback=100):
    c=cs[-lookback:]
    if len(c)<10: return {"trend":"INSUFFICIENT_DATA","hh":0,"hl":0,"lh":0,"ll":0}
    hs,ls=pivots(c); hh=hl=lh=ll=0
    for a,b in zip(hs,hs[1:]):
        hh += b[1]>a[1]; lh += b[1]<a[1]
    for a,b in zip(ls,ls[1:]):
        hl += b[1]>a[1]; ll += b[1]<a[1]
    if hh and hl and hh+hl>lh+ll: t="BULLISH"
    elif lh and ll and lh+ll>hh+hl: t="BEARISH"
    else: t="RANGE/UNCLEAR"
    return {"trend":t,"hh":hh,"hl":hl,"lh":lh,"ll":ll,
            "pivot_highs":len(hs),"pivot_lows":len(ls)}

def engulfing(cs):
    if len(cs)<2: return {"bullish":False,"bearish":False}
    a,b=cs[-2],cs[-1]
    return {
      "bullish":bear(a) and bull(b) and b.open<=a.close and b.close>=a.open,
      "bearish":bull(a) and bear(b) and b.open>=a.close and b.close<=a.open
    }

def detect_levels(cs,tolerance=0.0012,min_touches=2):
    hs,ls=pivots(cs)
    raw=[]
    for kind,pts in (("S",ls),("R",hs)):
        for _,level in pts:
            touches=[]
            for j,c in enumerate(cs):
                value=c.low if kind=="S" else c.high
                if abs(value-level)/max(abs(level),1e-9)<=tolerance:
                    touches.append(j)
            if len(touches)>=min_touches:
                raw.append({"base":kind,"level":level,"touches":len(touches),
                             "first_touch":touches[0],"last_touch":touches[-1]})
    raw.sort(key=lambda z:(-z["touches"],abs(z["level"]-cs[-1].close)))
    zones=[]
    for z in raw:
        if any(abs(z["level"]-u["level"])/max(abs(z["level"]),1e-9)<=tolerance for u in zones):
            continue
        zones.append(z)
    return zones[:20]

def classify(cs,zones):
    out=[]
    for z in zones:
        level=z["level"]; last=z["last_touch"]; typ="S/R CANDIDATE"
        later=cs[last+1:] if last+1<len(cs) else []
        if z["base"]=="S" and any(c.close>level for c in later[-12:]): typ="V.S"
        if z["base"]=="R" and any(c.close<level for c in later[-12:]): typ="V.R"
        for k in range(max(1,last-8),min(len(cs),last+12)):
            p,c=cs[k-1],cs[k]
            if z["base"]=="S" and p.close>=level and c.close<level:
                typ="SBR"; break
            if z["base"]=="R" and p.close<=level and c.close>level:
                typ="RBS"; break
        z=dict(z,type=typ)
        if z["touches"]>=2 and z["last_touch"]-z["first_touch"]>=2:
            z["po2_candidate"]=True
        out.append(z)
    return out

def analyze(cs,timeframe):
    st=structure(cs); eg=engulfing(cs); zones=classify(cs,detect_levels(cs))
    buys=[z for z in zones if z["type"] in BUY_ZONES]
    sells=[z for z in zones if z["type"] in SELL_ZONES]
    selected=zones[0]["level"] if zones else None
    liq={"sweep":False,"run":False,"direction":None}
    if selected is not None:
        c=cs[-1]
        liq["sweep"]=(c.high>selected and c.close<=selected) or (c.low<selected and c.close>=selected)
        liq["run"]=c.close>selected or c.close<selected
        liq["direction"]="UP" if c.close>selected else ("DOWN" if c.close<selected else None)
    if st["trend"]=="BULLISH" and buys: status="BUY FRAMEWORK CANDIDATE"
    elif st["trend"]=="BEARISH" and sells: status="SELL FRAMEWORK CANDIDATE"
    else: status="WAIT / NO CONFIRMED SNRZ SETUP"
    return {
      "timeframe":timeframe,"status":status,"latest":asdict(cs[-1]),
      "structure":st,"engulfing":eg,"selected_level":selected,
      "liquidity":liq,"zones":zones[:12],
      "buy_candidates":buys[:6],"sell_candidates":sells[:6],
      "reasons":([("Liquidity Sweep candidate" if liq["sweep"] else ""),
                   ("Liquidity Run candidate" if liq["run"] else ""),
                   ("Bullish Engulfing candidate" if eg["bullish"] else ""),
                   ("Bearish Engulfing candidate" if eg["bearish"] else "")]),
      "limitations":["Automatic labels are candidates; they are not claimed as complete visual PDF confirmation."]
    }

def multi_timeframe(all_candles):
    order=["1mo","1w","1d","4h","1h","30m","15m","5m","1m"]
    out={tf:analyze(all_candles[tf],tf) for tf in order if tf in all_candles}
    trends={tf:x["structure"]["trend"] for tf,x in out.items()}
    bull=sum(v=="BULLISH" for v in trends.values())
    bear=sum(v=="BEARISH" for v in trends.values())
    alignment="BULLISH-LEANING" if bull>bear and bull>=2 else ("BEARISH-LEANING" if bear>bull and bear>=2 else "MIXED/UNCLEAR")
    return {"symbol":"XAU/USD","structure_alignment":alignment,
            "trend_counts":{"bullish":bull,"bearish":bear,"other":len(out)-bull-bear},
            "timeframes":out}
