# SNRZ AI V7 — Live SNRZ Analysis

Architecture:
1. GitHub Pages serves `index.html`.
2. Vercel runs `api/index.py`.
3. Vercel reads XAU/USD OHLC from Twelve Data.
4. `snrz_engine.py` applies SNRZ-only candidate logic.
5. Frontend displays multi-timeframe structure and SNRZ zones.

IMPORTANT:
- Replace `YOUR-VERCEL-DOMAIN` in `index.html` with the deployed backend domain.
- Set `TWELVE_DATA_API_KEY` only in Vercel Environment Variables.
- Do not put the real key in GitHub.
- Paper/educational analysis only; no live trade execution.
