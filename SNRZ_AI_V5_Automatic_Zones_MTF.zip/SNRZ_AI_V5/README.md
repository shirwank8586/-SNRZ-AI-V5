# SNRZ AI V5
Automatic SNRZ zone candidates + multi-timeframe XAU/USD analysis.

This is a conservative analysis/paper prototype. It does not execute trades. Labels are candidates unless the available OHLC evidence supports the required condition.

Run: `pip install -r requirements.txt` then set `TWELVE_DATA_API_KEY` and run `uvicorn backend.app:app --host 0.0.0.0 --port 8000`.
